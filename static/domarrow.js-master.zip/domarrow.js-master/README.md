# domarrow.js

This javascript library can draw connector line/arrow between any two DOM-element. Without any dependency.
